﻿using System;

namespace Tambahanclass
{
    class player
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Selamat datang di Game My Adventure");
            Console.WriteLine("siapa Nama anda?");
            Novice player = new Novice();
            player.Name = Console.ReadLine();
            Console.WriteLine("Hai " +player.Name+ ", siap utuk memulai petualangan?[y/n]");
            string bReady = Console.ReadLine();
            if(bReady=="y")
            {
                Console.WriteLine(player.Name+ " Telah siap memasuki Game untuk memulai petualangan...");
                Villain villain1 = new Villain("Beast");
                Console.WriteLine(player.Name+ " kamu menyerang " +villain1.Name);
                Console.WriteLine(villain1.Name+ " menyerang mu...");
                Console.WriteLine("Giliranmu, pilih gerakan selanjutnya :");
                Console.WriteLine("1. Single Attack");
                Console.WriteLine("2. Spesial Attack");
                Console.WriteLine("3. Defend");
                Console.WriteLine("4. run Away");
                Console.WriteLine("5. Heal");

                while (!player.IsDead  && !villain1.IsDead)
                {
                    string playerAction = Console.ReadLine();
                    switch (playerAction)
                    {
                        case "1" : 
                        Console.WriteLine(player.Name+ " melakukan serangan biasa kepada lawan");
                        villain1.GetHit(player.AttackPower);
                        player.Experience += 0.1f;
                        villain1.Attack(villain1.AttackPower);
                        player.GetHit(villain1.AttackPower);
                        Console.WriteLine("Player Health : "+player.Health+ " | Villain Health : "+villain1.Health+"\n");
                        break;
                        case "2" :
                        Console.WriteLine(player.Name+ " menggunakan spesial Attack kepada lawan");
                        player.SpesialAttack();
                        villain1.GetHit(player.AttackPower);
                        player.Experience += 0.1f;
                        Console.WriteLine("Player Health : "+player.Health+ "   | Villain Health : "+villain1.Health+"\n");
                        break;
                        case "3" :
                        Console.WriteLine(player.Name+ " melakukan perlindungan terhadap serangan lawan");
                        player.Rest();
                        villain1.Attack(villain1.AttackPower);
                        player.GetHit(villain1.AttackPower);
                        break;
                        case "4" :
                        Console.WriteLine(player.Name+ " kalah, lari dari pertempuran");
                        break;
                        case "5" :
                        Console.WriteLine(player.Name+ " memilih untuk mengisi kembali darahmu");
                        player.Heal();
                        villain1.Attack(villain1.AttackPower);
                        player.GetHit(villain1.AttackPower);
                        Console.WriteLine("Player Health : "+player.Health+ "   | Villain Health : "+villain1.Health+"\n");
                        break;
                    }
                }

                Console.WriteLine(player.Name+ " mendapatkan " +player.Experience+ " experience");
            }
            else
            {
                Console.WriteLine("Goodbye..");
                Console.Read();
            }
        }
    }

    class Novice
    {
        public int Health { get; set; }
        public int AttackPower { get; set; }
        public string Name { get; set; }
        public int PowerSpesialAttack { get; set; }
        public bool IsDead { get; set; }
        public float Experience { get; set; }
        Random  rnd = new Random();

        public Novice()
        {
            Health = 500;
            PowerSpesialAttack = 0;
            AttackPower = 25;
            IsDead = false;
            Experience = 0;
        }

        public void SpesialAttack()
        {
            if(PowerSpesialAttack > 0)
            {
                Console.WriteLine("Got Youuu!!!");
                AttackPower = AttackPower + rnd.Next(1,10);
                PowerSpesialAttack--;
            }
            else
            {
                Console.WriteLine("Anda Belom memiliki Spesial Attack!");
            }
        }

        public void GetHit(int HitValue)
        {
            Console.WriteLine(Name+ " kena serangan dari "+HitValue);
            Health = Health - HitValue;

            if(Health <=0)
            {
                //Health = 0;
                Die();
            }
        }

        public void Rest()
        {
            PowerSpesialAttack = 3;
            AttackPower = 1;
        }

        public void Heal()
        {
            Health = Health + rnd.Next(1,25);
        }

        public void Die()
        {
            Console.WriteLine(Name+ " telah dikalahkan");
            IsDead = true;
        }
    }

    class Villain
    {
        public int Health { get; set; }
        public int AttackPower { get; set; }
        public bool IsDead { get; set; }
        public string Name { get; set; }
        Random rnd = new Random();

        public Villain(string name)
        {
            Health = 500;
            IsDead = false;
            Name = name;
        }

        public void Attack(int Damage)
        {
            AttackPower = rnd.Next(1,25);
        }

        public void GetHit(int HitValue)
        {
            Console.WriteLine(Name+ " kena serangan dari "+HitValue);
            Health = Health - HitValue;

            if(Health <=0)
            {
                //Health = 0;
                Die();
            }
        }

        public void Die()
        {
            Console.WriteLine(Name+ " telah dikalahkan");
            IsDead = true;
        }
    } 
}